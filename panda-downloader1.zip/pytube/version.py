# -*- coding: utf-8 -*-

__version__ = "ob-v2"

if __name__ == "__main__":
    print(__version__)
